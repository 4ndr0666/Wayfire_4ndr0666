#File: $USER/.config/wayfire/theme/default.bash
#Author: 4ndr0666
#Edited: 03-30-24

# --- // 4NDR0666_DEFAULT_THEME // ========

# --- // COLORS:
background='#000101'
foreground='#8cd8e5'
color0='#000101'
color1='#0E718F'
color2='#076D93'
color3='#1586A1'
color4='#108FB2'
color5='#18B4D4'
color6='#21ABCC'
color7='#8cd8e5'
color8='#6297a0'
color9='#0E718F'
color10='#076D93'
color11='#1586A1'
color12='#108FB2'
color13='#18B4D4'
color14='#21ABCC'
color15='#8cd8e5'

# --- // WALLPAPER:
wallpaper="$HOME/.config/wayfire/wallpapers/Archwave4ndr0.png"
