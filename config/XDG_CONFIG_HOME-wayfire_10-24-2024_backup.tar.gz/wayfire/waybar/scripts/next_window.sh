#!/bin/bash
# Press Alt, press Tab, release Tab, release Alt
wtype -M alt -P Tab -p Tab -m alt

