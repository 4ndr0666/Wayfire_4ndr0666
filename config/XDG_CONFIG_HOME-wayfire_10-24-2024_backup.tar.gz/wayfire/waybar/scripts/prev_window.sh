#!/bin/bash
# Press Alt and Shift, press Tab, release Tab, release Shift and Alt
wtype -M alt -M shift -P Tab -p Tab -m shift -m alt

