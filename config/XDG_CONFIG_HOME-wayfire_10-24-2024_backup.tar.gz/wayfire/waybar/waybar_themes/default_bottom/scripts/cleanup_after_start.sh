#!/bin/sh

sleep 20
hyprctl keyword windowrule "workspace unset,nmtui-colors"
hyprctl keyword windowrule "workspace unset,calamares"
hyprctl keyword windowrule "workspace unset,keyhint.sh"
hyprctl keyword windowrule "workspace unset,firedragon"
